import type { ApiDocListItem } from '../../types/ApiDoc';

interface ApiTableProps {
  data: ApiDocListItem[];
  onRowClick: (api: ApiDocListItem) => void;
  selectedDomain: string;
}

const ApiTable = ({ data, onRowClick, selectedDomain }: ApiTableProps) => {
  // Filter data based on selected domain
  const filteredData =
    selectedDomain === 'ALL'
      ? data
      : data.filter(api => api.category === selectedDomain);

  return (
    <table className="w-full h-full border-collapse">
      <thead>
        <tr className="bg-gray-100 border-b-2 border-gray-300">
          <th className="py-3 px-2">ID</th>
          <th className="py-3 px-2">API명</th>
          <th className="py-3 px-2">경로</th>
          <th className="py-3 px-2">메소드</th>
          <th className="py-3 px-2">카테고리</th>
          <th className="py-3 px-2">설명</th>
        </tr>
      </thead>
      <tbody>
        {filteredData.map(api => (
          <tr
            key={api.apiSpecId}
            className="cursor-pointer bg-white border-b border-gray-200 hover:bg-slate-50 transition"
            onClick={() => onRowClick(api)}
          >
            <td className="py-4 px-2 text-center">{api.apiSpecId}</td>
            <td className="py-4 px-2 text-center">{api.apiName}</td>
            <td className="py-4 px-2">{api.endpoint}</td>
            <td className="py-4 px-2 text-center">
              <span
                className={`px-3 py-1 rounded text-white font-bold text-sm ${
                  api.method === 'GET'
                    ? 'bg-emerald-500'
                    : api.method === 'POST'
                      ? 'bg-sky-500'
                      : api.method === 'PUT'
                        ? 'bg-amber-500'
                        : api.method === 'DELETE'
                          ? 'bg-rose-500'
                          : 'bg-slate-400'
                }`}
              >
                {api.method}
              </span>
            </td>
            <td className="py-4 px-2 text-center">
              <span className="px-4 py-2 rounded font-bold bg-white text-cyan-900">
                {api.category}
              </span>
            </td>
            <td
              className="py-4 px-2 truncate max-w-[200px]"
              title={api.description}
            >
              {api.description.length > 30
                ? `${api.description.substring(0, 30)}...`
                : api.description}
            </td>
          </tr>
        ))}
      </tbody>
    </table>
  );
};

export default ApiTable;
