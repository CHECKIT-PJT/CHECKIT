import ChapterSelect from '../../components/chapter/ChapterSelect';

const BuildSelect = () => {
  return <ChapterSelect />;
};

export default BuildSelect;
