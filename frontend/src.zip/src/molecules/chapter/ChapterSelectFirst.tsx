import ChapterSelect from '../../components/chapter/ChapterSelect';

const ChapterSelectFirst = () => {
  return <ChapterSelect />;
};

export default ChapterSelectFirst;
