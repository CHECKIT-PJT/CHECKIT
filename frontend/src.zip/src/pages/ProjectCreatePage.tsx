const ProjectCreatePage = () => {
  return <div>ProjectCreatePage</div>;
};

export default ProjectCreatePage;
